import React from 'react'

export default function Models(){
    return(
		<div>
        Model S
        </div>
    )
}
import React from 'react'
import NavItem from './NavItem'
import { Outlet } from "react-router-dom";

export default function Navigation(){
    return(
        <div>
            <NavItem path="/" label="Home"></NavItem>
            <NavItem path="/models" label="Model S"></NavItem>
            <Outlet />
        </div>
    )
    }